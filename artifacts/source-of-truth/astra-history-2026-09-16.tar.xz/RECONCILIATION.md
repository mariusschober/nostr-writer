# Astra research/product reconciliation — 2026-09-16

This repository is the source of truth for the Human Writing Provenance / Human Writing Protocol work generated in the preceding ChatGPT/Astra sessions and the Nostr Writer for Mac implementation handoff.

## Previously present on GitHub

Before reconciliation, the research foundation and HWP-C/1 cryptographic candidate were committed. HWP-A 0.3 had its specification/results but was missing executable source/tests. The joined frozen Human Writing Protocol v0 and the complete Mac MVP handoff were not directly materialized. Several failed upload attempts left unreachable blobs or probe files.

## Materialized source of truth

- `algorithm/v0_3/`: complete HWP-A 0.3.0 generated package, including executable source, tests, artifacts and checks.
- `proof/hwp-c-1/`: complete HWP-C/1 cryptographic candidate.
- `protocol/v0/`: complete frozen joined Human Writing Protocol v0, definition SHA-256 `58efebeb46689cfafd597230facda03a9541d423b244d36b84cff35b2fc8c6d4`.
- `product/mac/`: complete Mac MVP product, architecture, UX, storage, HWP, Nostr, export, focus and security contracts; eight PLAN prompts; eight START prompts; sixty mandatory completion criteria.
- `mac/Packages/WriterFoundation/`: the preparation helper package. Its original source files were not preserved as conversation attachments; the current source/tests are an explicit reconstruction from preserved contracts and reproduce the recorded 47/47 portable test result.
- `history/hwp-a-0.2.0/`: the earlier HWP-A 0.2.0 generated source package preserved for historical interpretation.
- `history/generated-artifacts/`: downloadable ZIP/PATCH/spec/result artifacts generated during earlier turns and retained as historical build outputs.
- `history/mac-preparation-original/`: exact preserved preparation-era INPUTS/bootstrap files that predated direct protocol materialization.

## Byte preservation

HWP-A 0.2, HWP-A 0.3, HWP-C/1 and frozen HWP v0 files are sourced from the generated ZIP artifacts retained in the conversation runtime. The Mac PLAN/START/product documents are copied from the exact generated conversation attachments. Where a historical artifact is superseded by a current operational file, the historical bytes remain under `history/`.

## Scientific boundary

Repository completeness does not create scientific validity. No real participant detector model, independently admitted native capture profile, production HWP authority or real Human Writing Proof issuance is established by this reconciliation. `NOT PROVABLE` never means AI-written.

## Verification

```sh
python3 tools/check_preparation.py
python3 tools/bootstrap_protocol.py
python3 protocol/v0/tools/check_freeze.py
python3 -m unittest discover -s algorithm/v0_3/tests -v
swift test --package-path mac/Packages/WriterFoundation
```

Protocol v0 retains its own conformance results and test vectors. Native macOS UI, File Provider, Word/Pages, relay and notarization acceptance remain implementation-stage work.
