# Nostr Writer implementation agents

Read `product/mac/README.md` before changing the application. Execute exactly the requested numbered PLAN and its inherited acceptance gates. The product is a native writing-first Mac app, not a menubar-only NostrShot clone, Electron wrapper, telemetry dashboard, or anti-AI classifier.

`protocol/v0` is the frozen joined Human Writing Protocol input. Root `algorithm/` and `proof/` are historical components and are not interchangeable substitutes. Never rewrite frozen manifests, invent capture observations, approve test policies, label Nostr signing as HWP, or sign NOT PROVABLE. Current real-world approvals are empty. Do not make a fake always-negative implementation to avoid building genuine positive/negative conformance paths.

Protect text first: atomic coordinated source saves, encrypted local recovery before network, lossless conflict handling, and no cloud-sync-complete claim from a file write. Keep raw behavioural evidence private. No ordinary secrets in source, stdout, test reports, UserDefaults, or public exports.

Record actual commands and platforms. Linux Swift tests do not establish native macOS UI correctness. Mac-only tests require actual Mac execution; missing Apple signing credentials block release sign-off, not permission to report an unsigned ZIP as complete. Use public Apple APIs and preserve emergency escape in forced sessions.

Keep changes bounded to a stage, pin dependencies, run existing tests, update `product/mac/evidence/STAGE-0N.md` and `.json`, and commit the stage with its next-stage handoff. Do not advance past failed mandatory gates.
